<?php

/**
 * 应用常量
 */
define('EMAIL', FILTER_VALIDATE_EMAIL);
define('URL', FILTER_VALIDATE_URL);
define('IP', FILTER_VALIDATE_IP);
define('INT', FILTER_VALIDATE_INT);
define('FLOAT', FILTER_VALIDATE_FLOAT);
define('MONEY', '/^(([1-9]{1}\d*)|([0]{1}))(\.(\d){1,2})?$/');
define('MOBILE', '/^1[34578][0-9]{9,9}$/');
define('APPID', 'wx99db8e13bbd0ddd3');
define('SECRET', 'bd73e80f376f06995f25940796b65a46');
define('ACTIVE_TYPE', 0);



