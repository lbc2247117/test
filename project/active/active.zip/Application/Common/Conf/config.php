<?php

return array(
    'MODULE_ALLOW_LIST' => array('Home', 'Admin',),
    'DEFAULT_MODULE' => 'Home', // 默认模块	
    // 'SHOW_PAGE_TRACE' => true,
    'URL_MODEL' => 2,
    'URL_CASE_INSENSITIVE' => true, //url不区分大小写
    'URL_HTML_SUFFIX' => '',
    'SHOW_ERROR_MSG' => true,
    'LOAD_EXT_CONFIG' => 'db,const',
);
